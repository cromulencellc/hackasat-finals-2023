-- example lua script

-- UDP is passed in as an arg
-- Print is passed in as an arg
local args = {...}
local udp = select(1  , ... )
local print = select(2, ... )
-- udp settings reccomended to leave these alone
udp:settimeout( 10 )
assert(udp:setsockname("*",0))
-- connect to the flight software port 9000
assert(udp:setpeername("127.0.0.1", 9000))

-- Log is limited to 5 kilobytes per script execution
-- please dont needlessly spam the script log
print("This will now go to a log that admin can download")

-- Ask the gps receiver for a position
local cmd = string.pack( "b", 0) -- command id 0 for gps
local data = "POS" -- ask for gps geodetic info

udp:send( cmd ) -- send 1 byte message for command id
udp:send( data ) -- Send a data message that is a string